sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel", "sap/ui/core/util/Export",
    "sap/ui/core/util/ExportTypeCSV"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, Export, ExportTypeCSV) {
        "use strict";
        var smartData = new JSONModel();
        return Controller.extend("project1.controller.View1", {
            onInit: function () {
                fetch("https://port4004-workspaces-ws-bt4q5.us10.trial.applicationstudio.cloud.sap/odata/v4/catalog/ReportData",{
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify()
                })
                    .then(response => response.json())
                    .then(data => {
                        var that = this;
                        console.log("after teransform the data", data);
                        // debugger;
                        // var smartData = new JSONModel();
                        smartData.setData(data.value);
                        this.getView().setModel(smartData, "loadData");
                        console.log(" model  data", smartData)
                    })
                    .catch(error => {
                        console.error("Failed :", error);
                        // Optionally handle the error
                    });
            },
            onFilterPress: function () {
                const oView = this.getView();
                const projectID = oView.byId("projectId").getValue();
                const startDate = oView.byId("fromDate").getValue();
                const endDate = oView.byId("toDate").getValue();

                const payload = {
                    projectID: projectID,
                    startDate: new Date(startDate).toISOString(),
                    endDate: new Date(endDate).toISOString()
                };

                fetch('https://port4004-workspaces-ws-bt4q5.us10.trial.applicationstudio.cloud.sap/odata/v4/catalog/filterArray', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(payload),
                })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        console.log("Response from server:", data);

                        smartData.setData(data.ReportData);
                        this.getView().setModel(smartData, "loadData");
                        console.log("Filtered data:", smartData.getData());

                    })
                    .catch(error => {
                        console.error('Error:', error);
                        // alert("Error filtering data: " + error);
                    });
            },

            onResetPress: function () {
                console.log("Reset button pressed");
                // Get the input controls by their IDs
                var fromDatePicker = this.getView().byId("fromDate").setValue("");
                var toDatePicker = this.getView().byId("toDate").setValue("");
                var projectIdInput = this.getView().byId("projectId").setValue("");
                window.location.reload();
              

            },
            OnProject: function () {
                // Assuming you have a table with id "myTable" and you want to export its data
                var oTable = this.getView().byId("glsection");
                var oExport = new sap.ui.core.util.Export({
                    exportType: new sap.ui.core.util.ExportTypeCSV({
                        separatorChar: "\t"
                    }),
                    models: oTable.getModel(),
                    rows: {
                        path: "/loadData",
                        filters: []
                    },
                    columns: [{
                        name: "Project Id",
                        template: {
                            content: "{CPROJECT_UUID_01}"

                        }
                    },
                    {
                        name: "Posting Date",
                        template: {
                            content: "{CPOSTING_DATE}"

                        }
                    },
                    {
                        name: "Gl Account type",
                        template: {
                            content: "{TGLACCT_TC}"
                        }
                    },
                    {
                        name: "Gl Account ",
                        template: {
                            content: "{CGLACCT}"
                        }
                    },
                    {
                        name: "Description",
                        template: {
                            content: "{TGLACCT}"
                        }
                    },
                    {
                        name: "Company Currency Amount (USD)",
                        template: {
                            content: "{company_currency_amount}"
                        }
                    },
                    {
                        name: "Revenue (USD)",
                        template: {
                            content: "{revenue}"
                        }
                    },
                    {
                        name: "COGS (USD)",
                        template: {
                            content: "{cogs}"
                        }
                    }
                        ,
                    {
                        name: "Total P/L (USD)",
                        template: {
                            content: "{total_pl}"
                        }
                    }
                        ,
                    {
                        name: "Sales Order Net Value (USD)",
                        template: {
                            content: "{KCZ099A5E5FF2637757812202}"
                        }
                    }
                    ]

                });

                // Handle the export
                oExport.saveFile().catch(function (oError) {
                    // Handle any errors during export
                }).then(function () {
                    // Clean up
                    oExport.destroy();
                });
            },
            onHierarchy: function () {
                // Assuming you have a table with id "myTable" and you want to export its data
                var oTable = this.getView().byId("glsection");
                var oExport = new sap.ui.core.util.Export({
                    exportType: new sap.ui.core.util.ExportTypeCSV({
                        separatorChar: "\t"
                    }),
                    models: oTable.getModel(),
                    rows: {
                        path: "/loadData",
                        filters: []
                    },
                    columns: [{
                        name: "Project Id",
                        template: {
                            content: "{CPROJECT_UUID_01}"

                        }
                    },
                    {
                        name: "Posting Date",
                        template: {
                            content: "{CPOSTING_DATE}"

                        }
                    },
                    {
                        name: "Gl Account type",
                        template: {
                            content: "{TGLACCT_TC}"
                        }
                    },
                    {
                        name: "Gl Account ",
                        template: {
                            content: "{CGLACCT}"
                        }
                    },
                    {
                        name: "Description",
                        template: {
                            content: "{TGLACCT}"
                        }
                    },
                    {
                        name: "Company Currency Amount (USD)",
                        template: {
                            content: "{company_currency_amount}"
                        }
                    },
                    {
                        name: "Revenue (USD)",
                        template: {
                            content: "{revenue}"
                        }
                    },
                    {
                        name: "COGS (USD)",
                        template: {
                            content: "{cogs}"
                        }
                    }
                        ,
                    {
                        name: "Total P/L (USD)",
                        template: {
                            content: "{total_pl}"
                        }
                    }
                        ,
                    {
                        name: "Sales Order Net Value (USD)",
                        template: {
                            content: "{KCZ099A5E5FF2637757812202}"
                        }
                    }
                    ]

                });

                // Handle the export
                oExport.saveFile().catch(function (oError) {
                    // Handle any errors during export
                }).then(function () {
                    // Clean up
                    oExport.destroy();
                });
            },
            onDetailed: function () {
                // Assuming you have a table with id "myTable" and you want to export its data
                var oTable = this.getView().byId("glsection");
                var oExport = new sap.ui.core.util.Export({
                    exportType: new sap.ui.core.util.ExportTypeCSV({
                        separatorChar: "\t"
                    }),
                    models: oTable.getModel(),
                    rows: {
                        path: "/loadData",
                        filters: []
                    },
                    columns: [{
                        name: "Project Id",
                        template: {
                            content: "{CPROJECT_UUID_01}"

                        }
                    },
                    {
                        name: "Posting Date",
                        template: {
                            content: "{CPOSTING_DATE}"

                        }
                    },
                    {
                        name: "Gl Account type",
                        template: {
                            content: "{TGLACCT_TC}"
                        }
                    },
                    {
                        name: "Gl Account ",
                        template: {
                            content: "{CGLACCT}"
                        }
                    },
                    {
                        name: "Description",
                        template: {
                            content: "{TGLACCT}"
                        }
                    },
                    {
                        name: "Company Currency Amount (USD)",
                        template: {
                            content: "{company_currency_amount}"
                        }
                    },
                    {
                        name: "Revenue (USD)",
                        template: {
                            content: "{revenue}"
                        }
                    },
                    {
                        name: "COGS (USD)",
                        template: {
                            content: "{cogs}"
                        }
                    }
                        ,
                    {
                        name: "Total P/L (USD)",
                        template: {
                            content: "{total_pl}"
                        }
                    }
                        ,
                    {
                        name: "Sales Order Net Value (USD)",
                        template: {
                            content: "{KCZ099A5E5FF2637757812202}"
                        }
                    }
                    ]

                });

                // Handle the export
                oExport.saveFile().catch(function (oError) {
                    // Handle any errors during export
                }).then(function () {
                    // Clean up
                    oExport.destroy();
                });
            },
        });
    });